
import 'dart:ui';

class AppColors {
 //ben bu sayfayada bu renkleri lkullandım
  static final Color profilBackground = Color(0xFF1A0670);
  static final Color white = Color(0xFFFFFFFF);
  static final Color black = Color(0xFF000000);
  static final Color profilBackground2 = Color(0xFFDC2227);
  static final Color greyy = Color(0xFF696969);
  static final Color green = Color(0xFF00c0a6);
  static final Color krem1 = Color(0xFFFFDAB9);
  //bunlar sınrada eklendi şu sayfalarda kullanıldı dşye,
  static final Color krem2 = Color(0xFFFFDEAD);
  static final Color green2 = Color(0xFFB5F19B);
  static final Color blue = Color(0xFF00B5FF);
  static final Color green3= Color(0xff3cdba4);

// green 4F9355

}